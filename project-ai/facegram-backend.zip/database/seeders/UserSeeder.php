<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Fixed demo accounts (easy to test)
        User::create([
            'full_name'  => 'John Doe',
            'username'   => 'john.doe',
            'password'   => Hash::make('password'),
            'bio'        => 'The best way to predict the future is to create it.',
            'is_private' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        User::create([
            'full_name'  => 'Richard Roe',
            'username'   => 'richard.roe',
            'password'   => Hash::make('password'),
            'bio'        => 'Leave a little sparkle wherever you go.',
            'is_private' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        User::create([
            'full_name'  => 'Jane Poe',
            'username'   => 'jane.poe',
            'password'   => Hash::make('password'),
            'bio'        => 'Living life one adventure at a time.',
            'is_private' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Random dummy users
        User::factory(50)->create();
    }
}
