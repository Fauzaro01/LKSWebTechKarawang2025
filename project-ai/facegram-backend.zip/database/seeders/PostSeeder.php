<?php

namespace Database\Seeders;

use App\Models\Post;
use App\Models\PostAttachment;
use App\Models\User;
use Illuminate\Database\Seeder;

class PostSeeder extends Seeder
{
    public function run(): void
    {
        $users = User::all();

        foreach ($users as $user) {
            // Each user gets 3–8 posts
            $postCount = rand(3, 8);

            for ($i = 0; $i < $postCount; $i++) {
                $post = Post::create([
                    'caption'    => fake()->sentence(rand(5, 15)),
                    'user_id'    => $user->id,
                    'created_at' => fake()->dateTimeBetween('-1 year', 'now'),
                    'deleted_at' => null,
                ]);

                // Each post gets 1–3 attachments
                $attachmentCount = rand(1, 3);
                $extensions      = ['jpg', 'jpeg', 'png', 'webp'];

                for ($j = 0; $j < $attachmentCount; $j++) {
                    $ext      = fake()->randomElement($extensions);
                    $filename = fake()->unique()->lexify('????????????') . '.' . $ext;

                    PostAttachment::create([
                        'storage_path' => 'posts/' . $filename,
                        'post_id'      => $post->id,
                    ]);
                }
            }
        }
    }
}
