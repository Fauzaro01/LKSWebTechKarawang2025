<?php

namespace Database\Seeders;

use App\Models\Follow;
use App\Models\User;
use Illuminate\Database\Seeder;

class FollowSeeder extends Seeder
{
    public function run(): void
    {
        $users   = User::all();
        $userIds = $users->pluck('id')->toArray();

        $pairs = []; // track created pairs to avoid duplicates

        foreach ($users as $follower) {
            // Each user follows 5–15 random others
            $followCount   = rand(5, 15);
            $potentialTargets = array_diff($userIds, [$follower->id]);
            shuffle($potentialTargets);
            $targets = array_slice($potentialTargets, 0, $followCount);

            foreach ($targets as $followingId) {
                $key = $follower->id . '_' . $followingId;
                if (isset($pairs[$key])) {
                    continue;
                }
                $pairs[$key] = true;

                $targetUser = $users->find($followingId);
                // If private account → pending (is_accepted=0), else accepted
                $isAccepted = $targetUser->is_private ? rand(0, 1) : 1;

                Follow::create([
                    'follower_id'  => $follower->id,
                    'following_id' => $followingId,
                    'is_accepted'  => $isAccepted,
                    'created_at'   => fake()->dateTimeBetween('-1 year', 'now'),
                ]);
            }
        }
    }
}
