-- ============================================================
-- Facegram Database Schema
-- Compatible with MySQL 5.7+ / MariaDB 10.3+
-- Run: mysql -u root -p facegram < facegram.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS `facegram`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `facegram`;

-- ── users ────────────────────────────────────────────────────
CREATE TABLE `users` (
    `id`         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `full_name`  VARCHAR(255)        NOT NULL,
    `username`   VARCHAR(255)        NOT NULL,
    `password`   VARCHAR(255)        NOT NULL,
    `bio`        VARCHAR(255)        DEFAULT NULL,
    `is_private` TINYINT(1)          NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP           NULL DEFAULT NULL,
    `updated_at` TIMESTAMP           NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── posts ─────────────────────────────────────────────────────
CREATE TABLE `posts` (
    `id`         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `caption`    VARCHAR(255)        NOT NULL,
    `user_id`    BIGINT(20) UNSIGNED NOT NULL,
    `created_at` TIMESTAMP           NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP           NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `posts_user_id_foreign` (`user_id`),
    CONSTRAINT `posts_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── post_attachments ──────────────────────────────────────────
CREATE TABLE `post_attachments` (
    `id`           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `storage_path` VARCHAR(255)        NOT NULL,
    `post_id`      BIGINT(20) UNSIGNED NOT NULL,
    PRIMARY KEY (`id`),
    KEY `post_attachments_post_id_foreign` (`post_id`),
    CONSTRAINT `post_attachments_post_id_foreign`
        FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── follows ───────────────────────────────────────────────────
CREATE TABLE `follows` (
    `id`           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `follower_id`  BIGINT(20) UNSIGNED NOT NULL,
    `following_id` BIGINT(20) UNSIGNED NOT NULL,
    `is_accepted`  TINYINT(1)          NOT NULL DEFAULT 0,
    `created_at`   TIMESTAMP           NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `follows_follower_id_following_id_unique` (`follower_id`,`following_id`),
    KEY `follows_following_id_foreign` (`following_id`),
    CONSTRAINT `follows_follower_id_foreign`
        FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE,
    CONSTRAINT `follows_following_id_foreign`
        FOREIGN KEY (`following_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── personal_access_tokens (Sanctum) ─────────────────────────
CREATE TABLE `personal_access_tokens` (
    `id`             BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `tokenable_type` VARCHAR(255)        NOT NULL,
    `tokenable_id`   BIGINT(20) UNSIGNED NOT NULL,
    `name`           VARCHAR(255)        NOT NULL,
    `token`          VARCHAR(64)         NOT NULL,
    `abilities`      TEXT                DEFAULT NULL,
    `last_used_at`   TIMESTAMP           NULL DEFAULT NULL,
    `expires_at`     TIMESTAMP           NULL DEFAULT NULL,
    `created_at`     TIMESTAMP           NULL DEFAULT NULL,
    `updated_at`     TIMESTAMP           NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
    KEY `personal_access_tokens_tokenable_type_tokenable_id_index`
        (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── migrations tracking table ─────────────────────────────────
CREATE TABLE IF NOT EXISTS `migrations` (
    `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `migration` VARCHAR(255) NOT NULL,
    `batch`     INT          NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2024_01_01_000001_create_users_table', 1),
('2024_01_01_000002_create_posts_table', 1),
('2024_01_01_000003_create_post_attachments_table', 1),
('2024_01_01_000004_create_follows_table', 1),
('2024_01_01_000005_create_personal_access_tokens_table', 1);
