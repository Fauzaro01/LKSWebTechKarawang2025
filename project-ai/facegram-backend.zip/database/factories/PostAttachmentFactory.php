<?php

namespace Database\Factories;

use App\Models\Post;
use App\Models\PostAttachment;
use Illuminate\Database\Eloquent\Factories\Factory;

class PostAttachmentFactory extends Factory
{
    protected $model = PostAttachment::class;

    public function definition(): array
    {
        $extensions = ['jpg', 'jpeg', 'png', 'webp'];
        $ext        = $this->faker->randomElement($extensions);
        $filename   = $this->faker->unique()->lexify('????????') . '.' . $ext;

        return [
            'storage_path' => 'posts/' . $filename,
            'post_id'      => Post::factory(),
        ];
    }
}
