<?php

namespace Database\Factories;

use App\Models\Follow;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class FollowFactory extends Factory
{
    protected $model = Follow::class;

    public function definition(): array
    {
        return [
            'follower_id'  => User::factory(),
            'following_id' => User::factory(),
            'is_accepted'  => 1,
            'created_at'   => $this->faker->dateTimeBetween('-1 year', 'now'),
        ];
    }

    public function pending(): static
    {
        return $this->state(['is_accepted' => 0]);
    }
}
