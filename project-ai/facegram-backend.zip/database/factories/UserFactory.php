<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserFactory extends Factory
{
    protected $model = User::class;

    public function definition(): array
    {
        $firstName = $this->faker->firstName();
        $lastName  = $this->faker->lastName();
        $username  = strtolower($firstName) . '.' . strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $lastName));

        // Ensure username only has valid chars and min 3 length
        $username = preg_replace('/[^a-zA-Z0-9._]/', '', $username);
        if (strlen($username) < 3) {
            $username .= $this->faker->numerify('##');
        }

        return [
            'full_name'  => $firstName . ' ' . $lastName,
            'username'   => $username . $this->faker->unique()->numerify('###'),
            'password'   => Hash::make('password'),
            'bio'        => $this->faker->sentence(10),
            'is_private' => $this->faker->boolean(30), // 30% chance private
            'created_at' => $this->faker->dateTimeBetween('-2 years', 'now'),
            'updated_at' => now(),
        ];
    }

    /**
     * State for a public account.
     */
    public function public(): static
    {
        return $this->state(['is_private' => 0]);
    }

    /**
     * State for a private account.
     */
    public function private(): static
    {
        return $this->state(['is_private' => 1]);
    }
}
