<?php

use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\FollowController;
use App\Http\Controllers\Api\V1\PostController;
use App\Http\Controllers\Api\V1\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes — Facegram v1
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->group(function () {

    // ── Authentication (public) ──────────────────────────────────────────
    Route::prefix('auth')->group(function () {
        Route::post('/register', [AuthController::class, 'register']);
        Route::post('/login',    [AuthController::class, 'login']);

        // Logout requires a valid token
        Route::middleware('auth:sanctum')->group(function () {
            Route::post('/logout', [AuthController::class, 'logout']);
        });
    });

    // ── Protected Routes (require Sanctum token) ─────────────────────────
    Route::middleware('auth:sanctum')->group(function () {

        // Posts
        Route::post('/posts',         [PostController::class, 'store']);
        Route::delete('/posts/{id}',  [PostController::class, 'destroy']);
        Route::get('/posts',          [PostController::class, 'index']);

        // Following
        Route::get('/following',                          [FollowController::class, 'following']);
        Route::post('/users/{username}/follow',           [FollowController::class, 'follow']);
        Route::delete('/users/{username}/unfollow',       [FollowController::class, 'unfollow']);

        // Followers / Accept
        Route::put('/users/{username}/accept',            [FollowController::class, 'accept']);
        Route::get('/users/{username}/followers',         [FollowController::class, 'followers']);

        // Users
        // IMPORTANT: /users must come before /users/{username} to avoid route conflict
        Route::get('/users',                              [UserController::class, 'index']);
        Route::get('/users/{username}',                   [UserController::class, 'show']);
    });
});
