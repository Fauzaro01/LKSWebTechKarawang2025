<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', function () {
    return response()->json(['message' => 'Login page'], 200);
    // return view('login');
})->name('login');

Route::get('/register', function () {
    return response()->json(['message' => 'Register page'], 200);
    // return view('register');
})->name('register');