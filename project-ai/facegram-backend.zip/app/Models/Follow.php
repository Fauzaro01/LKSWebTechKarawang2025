<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Follow extends Model
{
    use HasFactory;

    /**
     * follows table only has created_at (no updated_at).
     */
    public $timestamps = false;

    protected $fillable = [
        'follower_id',
        'following_id',
        'is_accepted',
        'created_at',
    ];

    protected $casts = [
        'is_accepted' => 'integer',
        'created_at'  => 'datetime',
    ];

    // ─── Relationships ────────────────────────────────────────────────────────

    /**
     * The user who is following.
     */
    public function follower(): BelongsTo
    {
        return $this->belongsTo(User::class, 'follower_id');
    }

    /**
     * The user being followed.
     */
    public function following(): BelongsTo
    {
        return $this->belongsTo(User::class, 'following_id');
    }
}
