<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'full_name',
        'username',
        'password',
        'bio',
        'is_private',
    ];

    /**
     * The attributes that should be hidden for serialization.
     */
    protected $hidden = [
        'password',
    ];

    /**
     * The attributes that should be cast.
     */
    protected $casts = [
        'is_private' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Disable default timestamps update_at behavior
     * (posts table only has created_at, so we override on that model)
     */
    public $timestamps = true;

    // ─── Relationships ────────────────────────────────────────────────────────

    /**
     * Posts created by this user.
     */
    public function posts(): HasMany
    {
        return $this->hasMany(Post::class, 'user_id');
    }

    /**
     * Follow records where this user is the one doing the following.
     */
    public function followingRelations(): HasMany
    {
        return $this->hasMany(Follow::class, 'follower_id');
    }

    /**
     * Follow records where this user is being followed.
     */
    public function followerRelations(): HasMany
    {
        return $this->hasMany(Follow::class, 'following_id');
    }

    /**
     * Users that this user is following (accepted only).
     */
    public function following(): BelongsToMany
    {
        return $this->belongsToMany(
            User::class,
            'follows',
            'follower_id',
            'following_id'
        )->wherePivot('is_accepted', 1);
    }

    /**
     * Users that follow this user (accepted only).
     */
    public function followers(): BelongsToMany
    {
        return $this->belongsToMany(
            User::class,
            'follows',
            'following_id',
            'follower_id'
        )->wherePivot('is_accepted', 1);
    }

    // ─── Helper Methods ───────────────────────────────────────────────────────

    /**
     * Check if this user is following the given user (accepted).
     */
    public function isFollowing(User $user): bool
    {
        return Follow::where('follower_id', $this->id)
            ->where('following_id', $user->id)
            ->where('is_accepted', 1)
            ->exists();
    }

    /**
     * Check if this user has sent a follow request to the given user.
     */
    public function hasRequestedFollow(User $user): bool
    {
        return Follow::where('follower_id', $this->id)
            ->where('following_id', $user->id)
            ->where('is_accepted', 0)
            ->exists();
    }

    /**
     * Get the follow record between this user and another.
     */
    public function getFollowRecord(User $user): ?Follow
    {
        return Follow::where('follower_id', $this->id)
            ->where('following_id', $user->id)
            ->first();
    }

    /**
     * Get follow status string toward a given user.
     * Returns: "following" | "requested" | "not-following"
     */
    public function getFollowStatus(User $user): string
    {
        $follow = $this->getFollowRecord($user);

        if (!$follow) {
            return 'not-following';
        }

        return $follow->is_accepted ? 'following' : 'requested';
    }
}
