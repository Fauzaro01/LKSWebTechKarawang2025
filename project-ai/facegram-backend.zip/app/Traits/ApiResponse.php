<?php

namespace App\Traits;

use Illuminate\Http\JsonResponse;

trait ApiResponse
{
    protected function successResponse(
        array $data = [],
        int $statusCode = 200
    ): JsonResponse {
        return response()->json($data, $statusCode);
    }

    protected function errorResponse(
        string $message,
        int $statusCode,
        array $errors = []
    ): JsonResponse {
        $body = ['message' => $message];

        if (!empty($errors)) {
            $body['errors'] = $errors;
        }

        return response()->json($body, $statusCode);
    }

    protected function noContentResponse(): JsonResponse
    {
        return response()->json(null, 204);
    }
}
