<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class CreatePostRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'caption'      => ['required', 'string'],
            'attachments'  => ['required', 'array'],
            'attachments.*'=> ['required', 'file', 'mimes:jpg,jpeg,webp,png,gif'],
        ];
    }

    protected function failedValidation(Validator $validator): void
    {
        throw new HttpResponseException(
            response()->json([
                'message' => 'Invalid field',
                'errors'  => $validator->errors(),
            ], 422)
        );
    }
}
