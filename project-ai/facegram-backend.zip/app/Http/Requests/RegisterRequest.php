<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class RegisterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'full_name'  => ['required', 'string'],
            'bio'        => ['required', 'string', 'max:100'],
            'username'   => [
                'required',
                'string',
                'min:3',
                'unique:users,username',
                'regex:/^[a-zA-Z0-9._]+$/',
            ],
            'password'   => ['required', 'string', 'min:6'],
            'is_private' => ['sometimes', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'username.regex' => 'The username field may only contain alphanumeric characters, dots, and underscores.',
        ];
    }

    protected function failedValidation(Validator $validator): void
    {
        throw new HttpResponseException(
            response()->json([
                'message' => 'Invalid field',
                'errors'  => $validator->errors(),
            ], 422)
        );
    }
}
