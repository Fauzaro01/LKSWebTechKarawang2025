<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\FollowingUserResource;
use App\Models\User;
use App\Services\FollowService;
use App\Traits\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class FollowController extends Controller
{
    use ApiResponse;

    public function __construct(private readonly FollowService $followService) {}

    /**
     * POST /api/v1/users/:username/follow
     */
    public function follow(Request $request, string $username): JsonResponse
    {
        $targetUser = User::where('username', $username)->first();

        if (!$targetUser) {
            return $this->errorResponse('User not found', 404);
        }

        try {
            $status = $this->followService->follow($request->user(), $targetUser);

            return $this->successResponse([
                'message' => 'Follow success',
                'status'  => $status,
            ], 200);

        } catch (\Exception $e) {
            $code    = $e->getMessage();
            $httpCode = (int) $e->getCode();

            if ($code === 'self_follow') {
                return $this->errorResponse('You are not allowed to follow yourself', 422);
            }

            if (str_starts_with($code, 'already_followed:')) {
                $status = substr($code, strlen('already_followed:'));
                return response()->json([
                    'message' => 'You are already followed',
                    'status'  => $status,
                ], 422);
            }

            return $this->errorResponse('Something went wrong', 500);
        }
    }

    /**
     * DELETE /api/v1/users/:username/unfollow
     */
    public function unfollow(Request $request, string $username): JsonResponse
    {
        $targetUser = User::where('username', $username)->first();

        if (!$targetUser) {
            return $this->errorResponse('User not found', 404);
        }

        try {
            $this->followService->unfollow($request->user(), $targetUser);
            return $this->noContentResponse();

        } catch (\Exception $e) {
            if ($e->getMessage() === 'not_following') {
                return $this->errorResponse('You are not following the user', 422);
            }

            return $this->errorResponse('Something went wrong', 500);
        }
    }

    /**
     * GET /api/v1/following
     */
    public function following(Request $request): JsonResponse
    {
        $users = $this->followService->getFollowing($request->user());

        return $this->successResponse([
            'following' => FollowingUserResource::collection(collect($users)),
        ], 200);
    }

    /**
     * PUT /api/v1/users/:username/accept
     */
    public function accept(Request $request, string $username): JsonResponse
    {
        $requesterUser = User::where('username', $username)->first();

        if (!$requesterUser) {
            return $this->errorResponse('User not found', 404);
        }

        try {
            $this->followService->acceptFollow($request->user(), $requesterUser);

            return $this->successResponse(['message' => 'Follow request accepted'], 200);

        } catch (\Exception $e) {
            $code = $e->getMessage();

            if ($code === 'not_following_you') {
                return $this->errorResponse('The user is not following you', 422);
            }

            if ($code === 'already_accepted') {
                return $this->errorResponse('Follow request is already accepted', 422);
            }

            return $this->errorResponse('Something went wrong', 500);
        }
    }

    /**
     * GET /api/v1/users/:username/followers
     */
    public function followers(Request $request, string $username): JsonResponse
    {
        $targetUser = User::where('username', $username)->first();

        if (!$targetUser) {
            return $this->errorResponse('User not found', 404);
        }

        $users = $this->followService->getFollowers($targetUser);

        return $this->successResponse([
            'followers' => FollowingUserResource::collection(collect($users)),
        ], 200);
    }
}
