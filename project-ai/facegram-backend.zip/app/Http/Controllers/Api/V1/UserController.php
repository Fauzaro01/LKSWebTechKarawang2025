<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\UserService;
use App\Traits\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class UserController extends Controller
{
    use ApiResponse;

    public function __construct(private readonly UserService $userService) {}

    /**
     * GET /api/v1/users
     * Returns all users NOT followed by the auth user (excludes self).
     */
    public function index(Request $request): JsonResponse
    {
        $users = $this->userService->getUnfollowedUsers($request->user());

        return $this->successResponse([
            'users' => UserResource::collection($users),
        ], 200);
    }

    /**
     * GET /api/v1/users/:username
     */
    public function show(Request $request, string $username): JsonResponse
    {
        $targetUser = User::where('username', $username)->first();

        if (!$targetUser) {
            return $this->errorResponse('User not found', 404);
        }

        $data = $this->userService->getUserDetail($request->user(), $targetUser);

        return $this->successResponse($data, 200);
    }
}
