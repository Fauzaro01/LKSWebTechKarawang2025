<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Services\AuthService;
use App\Traits\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    use ApiResponse;

    public function __construct(private readonly AuthService $authService) {}

    /**
     * POST /api/v1/auth/register
     */
    public function register(RegisterRequest $request): JsonResponse
    {
        $result = $this->authService->register($request->validated());

        $user  = $result['user'];
        $token = $result['token'];

        return $this->successResponse([
            'message' => 'Register success',
            'token'   => $token,
            'user'    => [
                'full_name'  => $user->full_name,
                'bio'        => $user->bio,
                'username'   => $user->username,
                'is_private' => (bool) $user->is_private,
                'id'         => $user->id,
            ],
        ], 201);
    }

    /**
     * POST /api/v1/auth/login
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $result = $this->authService->login(
            $request->input('username'),
            $request->input('password')
        );

        if (!$result) {
            return $this->errorResponse('Wrong username or password', 401);
        }

        $user  = $result['user'];
        $token = $result['token'];

        return $this->successResponse([
            'message' => 'Login success',
            'token'   => $token,
            'user'    => [
                'id'         => $user->id,
                'full_name'  => $user->full_name,
                'username'   => $user->username,
                'bio'        => $user->bio,
                'is_private' => $user->is_private,
                'created_at' => $user->created_at->toISOString(),
            ],
        ], 200);
    }

    /**
     * POST /api/v1/auth/logout
     */
    public function logout(Request $request): JsonResponse
    {
        $this->authService->logout($request->user());

        return $this->successResponse(['message' => 'Logout success'], 200);
    }
}
