<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreatePostRequest;
use App\Http\Requests\GetPostsRequest;
use App\Http\Resources\PostResource;
use App\Models\Post;
use App\Services\PostService;
use App\Traits\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PostController extends Controller
{
    use ApiResponse;

    public function __construct(private readonly PostService $postService) {}

    /**
     * POST /api/v1/posts
     */
    public function store(CreatePostRequest $request): JsonResponse
    {
        $this->postService->createPost(
            user:            $request->user(),
            caption:         $request->input('caption'),
            attachmentFiles: $request->file('attachments')
        );

        return $this->successResponse(['message' => 'Create post success'], 201);
    }

    /**
     * DELETE /api/v1/posts/:id
     */
    public function destroy(Request $request, int $id): JsonResponse
    {
        $post = Post::whereNull('deleted_at')->find($id);

        if (!$post) {
            return $this->errorResponse('Post not found', 404);
        }

        // Authorization: only the owner can delete
        if ($post->user_id !== $request->user()->id) {
            return $this->errorResponse('Forbidden access', 403);
        }

        $this->postService->deletePost($post);

        return $this->noContentResponse();
    }

    /**
     * GET /api/v1/posts
     */
    public function index(GetPostsRequest $request): JsonResponse
    {
        $validated = $request->validated();

        $page = (int) ($validated['page'] ?? 0);
        $size = (int) ($validated['size'] ?? 10);

        $result = $this->postService->getPosts(
            authUser: $request->user(),
            page:     $page,
            size:     $size
        );

        return $this->successResponse([
            'page'  => $result['page'],
            'size'  => $result['size'],
            'posts' => PostResource::collection($result['posts']),
        ], 200);
    }
}
