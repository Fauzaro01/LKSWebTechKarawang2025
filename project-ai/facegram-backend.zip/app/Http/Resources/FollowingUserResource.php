<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class FollowingUserResource extends JsonResource
{
    /**
     * Used for both following and followers lists.
     * Requires $this->is_requested to be set on the model before wrapping.
     */
    public function toArray(Request $request): array
    {
        return [
            'id'           => $this->id,
            'full_name'    => $this->full_name,
            'username'     => $this->username,
            'bio'          => $this->bio,
            'is_private'   => $this->is_private,
            'created_at'   => $this->created_at instanceof \Carbon\Carbon
                ? $this->created_at->format('Y-m-d H:i:s')
                : $this->created_at,
            'is_requested' => (bool) ($this->is_requested ?? false),
        ];
    }
}
