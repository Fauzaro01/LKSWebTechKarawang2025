<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * The user sub-object embedded inside a Post response.
 * Matches the exact shape from the spec's GET /posts example.
 */
class PostUserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'         => $this->id,
            'full_name'  => $this->full_name,
            'username'   => $this->username,
            'bio'        => $this->bio,
            'is_private' => $this->is_private,
            'created_at' => $this->created_at instanceof \Carbon\Carbon
                ? $this->created_at->format('Y-m-d H:i:s')
                : $this->created_at,
        ];
    }
}
