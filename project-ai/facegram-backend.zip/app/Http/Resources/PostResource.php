<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PostResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'         => $this->id,
            'caption'    => $this->caption,
            'created_at' => $this->created_at instanceof \Carbon\Carbon
                ? $this->created_at->format('Y-m-d H:i:s')
                : $this->created_at,
            'deleted_at' => $this->deleted_at instanceof \Carbon\Carbon
                ? $this->deleted_at->format('Y-m-d H:i:s')
                : $this->deleted_at,
            'user'        => new PostUserResource($this->whenLoaded('user')),
            'attachments' => PostAttachmentResource::collection(
                $this->whenLoaded('attachments')
            ),
        ];
    }
}
