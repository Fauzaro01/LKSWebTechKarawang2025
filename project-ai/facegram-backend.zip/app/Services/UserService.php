<?php

namespace App\Services;

use App\Models\Follow;
use App\Models\Post;
use App\Models\User;
use Illuminate\Database\Eloquent\Collection;

class UserService
{
    /**
     * Get all users that the authenticated user is NOT following.
     * Also excludes the authenticated user themselves.
     */
    public function getUnfollowedUsers(User $authUser): Collection
    {
        // IDs of users the authenticated user follows (any status)
        $followingIds = Follow::where('follower_id', $authUser->id)
            ->pluck('following_id')
            ->toArray();

        // Exclude self and any followed/requested users
        $excludeIds = array_merge([$authUser->id], $followingIds);

        return User::whereNotIn('id', $excludeIds)->get();
    }

    /**
     * Get detailed user profile for :username.
     *
     * Posts are hidden if:
     *  - The target user is private AND
     *  - The auth user is NOT following them (status is not "following")
     */
    public function getUserDetail(User $authUser, User $targetUser): array
    {
        $isYourAccount   = $authUser->id === $targetUser->id;
        $followingStatus = $isYourAccount ? 'following' : $authUser->getFollowStatus($targetUser);

        // Determine post visibility
        $showPosts = true;
        if ($targetUser->is_private && !$isYourAccount && $followingStatus !== 'following') {
            $showPosts = false;
        }

        // Counts
        $postsCount     = Post::where('user_id', $targetUser->id)->whereNull('deleted_at')->count();
        $followersCount = Follow::where('following_id', $targetUser->id)->where('is_accepted', 1)->count();
        $followingCount = Follow::where('follower_id', $targetUser->id)->where('is_accepted', 1)->count();

        $data = [
            'id'               => $targetUser->id,
            'full_name'        => $targetUser->full_name,
            'username'         => $targetUser->username,
            'bio'              => $targetUser->bio,
            'is_private'       => $targetUser->is_private,
            'created_at'       => $targetUser->created_at->format('Y-m-d H:i:s'),
            'is_your_account'  => $isYourAccount,
            'following_status' => $followingStatus,
            'posts_count'      => $postsCount,
            'followers_count'  => $followersCount,
            'following_count'  => $followingCount,
        ];

        if ($showPosts) {
            $posts = Post::with('attachments')
                ->where('user_id', $targetUser->id)
                ->whereNull('deleted_at')
                ->orderBy('created_at', 'desc')
                ->get();

            $data['posts'] = $posts->map(function (Post $post) {
                return [
                    'id'         => $post->id,
                    'caption'    => $post->caption,
                    'created_at' => $post->created_at->format('Y-m-d H:i:s'),
                    'deleted_at' => $post->deleted_at,
                    'attachments'=> $post->attachments->map(fn ($a) => [
                        'id'           => $a->id,
                        'storage_path' => $a->storage_path,
                    ])->toArray(),
                ];
            })->toArray();
        }

        return $data;
    }
}
