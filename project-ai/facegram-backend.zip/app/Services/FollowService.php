<?php

namespace App\Services;

use App\Models\Follow;
use App\Models\User;

class FollowService
{
    /**
     * Follow a user.
     *
     * - If the target is a private account, create a follow request (is_accepted = 0).
     * - If the target is a public account, follow immediately (is_accepted = 1).
     *
     * Returns the follow status string: "following" | "requested".
     *
     * @throws \Exception When already followed or following self.
     */
    public function follow(User $authUser, User $targetUser): string
    {
        // Cannot follow yourself
        if ($authUser->id === $targetUser->id) {
            throw new \Exception('self_follow', 422);
        }

        // Check if already have a follow record
        $existing = Follow::where('follower_id', $authUser->id)
            ->where('following_id', $targetUser->id)
            ->first();

        if ($existing) {
            $status = $existing->is_accepted ? 'following' : 'requested';
            throw new \Exception('already_followed:' . $status, 422);
        }

        // Create follow record
        $isAccepted = $targetUser->is_private ? 0 : 1;

        Follow::create([
            'follower_id'  => $authUser->id,
            'following_id' => $targetUser->id,
            'is_accepted'  => $isAccepted,
            'created_at'   => now(),
        ]);

        return $isAccepted ? 'following' : 'requested';
    }

    /**
     * Unfollow a user.
     *
     * @throws \Exception When not following the user.
     */
    public function unfollow(User $authUser, User $targetUser): void
    {
        $follow = Follow::where('follower_id', $authUser->id)
            ->where('following_id', $targetUser->id)
            ->first();

        if (!$follow) {
            throw new \Exception('not_following', 422);
        }

        $follow->delete();
    }

    /**
     * Accept a follow request from a given user.
     *
     * @throws \Exception When user is not found, not following, or already accepted.
     */
    public function acceptFollow(User $authUser, User $requesterUser): void
    {
        $follow = Follow::where('follower_id', $requesterUser->id)
            ->where('following_id', $authUser->id)
            ->first();

        if (!$follow) {
            throw new \Exception('not_following_you', 422);
        }

        if ($follow->is_accepted) {
            throw new \Exception('already_accepted', 422);
        }

        $follow->is_accepted = 1;
        $follow->save();
    }

    /**
     * Get list of users that the authenticated user is following.
     * Includes both accepted and pending (requested) records.
     *
     * Returns a collection of User models with is_requested pivot info.
     */
    public function getFollowing(User $authUser): array
    {
        $follows = Follow::with('following')
            ->where('follower_id', $authUser->id)
            ->get();

        return $follows->map(function (Follow $follow) {
            $user               = $follow->following;
            $user->is_requested = !$follow->is_accepted;
            return $user;
        })->values()->all();
    }

    /**
     * Get list of followers for a given user.
     * Includes both accepted and pending (requested) records.
     */
    public function getFollowers(User $targetUser): array
    {
        $follows = Follow::with('follower')
            ->where('following_id', $targetUser->id)
            ->get();

        return $follows->map(function (Follow $follow) {
            $user               = $follow->follower;
            $user->is_requested = !$follow->is_accepted;
            return $user;
        })->values()->all();
    }
}
