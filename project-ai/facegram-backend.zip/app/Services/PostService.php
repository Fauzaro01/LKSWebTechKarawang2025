<?php

namespace App\Services;

use App\Models\Follow;
use App\Models\Post;
use App\Models\PostAttachment;
use App\Models\User;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Collection;

class PostService
{
    /**
     * Create a new post with its attachments.
     */
    public function createPost(User $user, string $caption, array $attachmentFiles): Post
    {
        $post = Post::create([
            'caption'    => $caption,
            'user_id'    => $user->id,
            'created_at' => now(),
        ]);

        foreach ($attachmentFiles as $file) {
            $path = $file->store('posts', 'public');

            PostAttachment::create([
                'storage_path' => $path,
                'post_id'      => $post->id,
            ]);
        }

        return $post;
    }

    /**
     * Delete a post and its attachments from storage.
     */
    public function deletePost(Post $post): void
    {
        // Remove physical files from storage
        foreach ($post->attachments as $attachment) {
            Storage::disk('public')->delete($attachment->storage_path);
        }

        // Soft-delete: set deleted_at timestamp
        $post->deleted_at = now();
        $post->save();
    }

    /**
     * Get paginated posts visible to the authenticated user.
     *
     * A post is visible if:
     *  1. It belongs to the authenticated user, OR
     *  2. It belongs to a user that the authenticated user is following (accepted).
     *
     * Posts are ordered by created_at descending (newest first).
     * Supports manual pagination via page (offset) and size (limit).
     */
    public function getPosts(User $authUser, int $page, int $size): array
    {
        // IDs of users the authenticated user follows (accepted)
        $followingIds = Follow::where('follower_id', $authUser->id)
            ->where('is_accepted', 1)
            ->pluck('following_id')
            ->toArray();

        // Include own posts
        $visibleUserIds = array_merge([$authUser->id], $followingIds);

        $offset = $page * $size;

        $posts = Post::with(['user', 'attachments'])
            ->whereNull('deleted_at')
            ->whereIn('user_id', $visibleUserIds)
            ->orderBy('created_at', 'desc')
            ->skip($offset)
            ->take($size)
            ->get();

        return [
            'page'  => $page,
            'size'  => $size,
            'posts' => $posts,
        ];
    }
}
