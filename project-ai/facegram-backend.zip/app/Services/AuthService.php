<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AuthService
{
    /**
     * Register a new user and return the user with token.
     */
    public function register(array $data): array
    {
        $user = User::create([
            'full_name'  => $data['full_name'],
            'bio'        => $data['bio'],
            'username'   => $data['username'],
            'password'   => Hash::make($data['password']),
            'is_private' => $data['is_private'] ?? false,
        ]);

        $token = $user->createToken('auth_token')->plainTextToken;

        return ['user' => $user, 'token' => $token];
    }

    /**
     * Attempt login and return the user with token on success.
     * Returns null if credentials are wrong.
     */
    public function login(string $username, string $password): ?array
    {
        $user = User::where('username', $username)->first();

        if (!$user || !Hash::check($password, $user->password)) {
            return null;
        }

        $token = $user->createToken('auth_token')->plainTextToken;

        return ['user' => $user, 'token' => $token];
    }

    /**
     * Logout the current user by deleting the current access token.
     */
    public function logout(User $user): void
    {
        // Delete only the token used in this request
        $user->currentAccessToken()->delete();
    }
}
