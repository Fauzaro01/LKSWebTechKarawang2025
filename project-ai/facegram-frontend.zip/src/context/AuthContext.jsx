import React, { createContext, useContext, useState, useCallback } from 'react';
import * as authService from '../services/authService';
import { getToken, setToken, getUser, setUser as persistUser, clearAuth } from '../utils/storage';

const AuthContext = createContext(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};

export default function AuthProvider({ children }) {
  const [user, setUser] = useState(getUser());
  const [token, setTokenState] = useState(getToken());

  const login = useCallback(async (credentials) => {
    const { data } = await authService.login(credentials);
    setToken(data.token);
    persistUser(data.user);
    setTokenState(data.token);
    setUser(data.user);
    return data;
  }, []);

  const register = useCallback(async (payload) => {
    const { data } = await authService.register(payload);
    setToken(data.token);
    persistUser(data.user);
    setTokenState(data.token);
    setUser(data.user);
    return data;
  }, []);

  const logout = useCallback(async () => {
    try {
      await authService.logout();
    } catch {
      // Even if the API call fails (e.g. token already expired),
      // we still want to clear the local session.
    } finally {
      clearAuth();
      setTokenState(null);
      setUser(null);
    }
  }, []);

  const value = {
    user,
    token,
    isAuthenticated: !!token,
    login,
    register,
    logout,
    setUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
