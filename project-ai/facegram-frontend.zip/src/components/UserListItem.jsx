import React from 'react';
import { Link } from 'react-router-dom';

export default function UserListItem({ user, action }) {
  return (
    <div className="d-flex align-items-center justify-content-between py-2 border-bottom">
      <Link
        to={`/profile/${user.username}`}
        className="d-flex align-items-center text-decoration-none flex-grow-1 text-truncate"
      >
        <i className="bi bi-person-circle fs-2 me-2 text-secondary"></i>
        <div className="text-truncate">
          <div className="fw-semibold text-dark text-truncate">{user.full_name}</div>
          <div className="text-muted small text-truncate">@{user.username}</div>
        </div>
      </Link>
      {action && <div className="ms-2 flex-shrink-0">{action}</div>}
    </div>
  );
}
