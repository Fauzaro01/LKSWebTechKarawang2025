import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import { toast } from 'react-toastify';
import { useAuth } from '../context/AuthContext';
import { deletePost } from '../services/postService';

const STORAGE_BASE_URL = import.meta.env.VITE_STORAGE_BASE_URL || 'http://localhost:8000/storage';

export default function PostCard({ post, onDeleted }) {
  const { user } = useAuth();
  const [deleting, setDeleting] = useState(false);

  const isOwner = user && post.user && (user.id === post.user.id || user.username === post.user.username);

  const handleDelete = async () => {
    const result = await Swal.fire({
      title: 'Delete this post?',
      text: 'This action cannot be undone.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Delete',
      confirmButtonColor: '#dc3545',
    });
    if (!result.isConfirmed) return;

    setDeleting(true);
    try {
      await deletePost(post.id);
      toast.success('Post deleted');
      onDeleted?.(post.id);
    } catch (err) {
      const status = err.response?.status;
      if (status === 403) toast.error('You are not allowed to delete this post');
      else if (status === 404) toast.error('Post not found');
      else toast.error('Failed to delete post');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="card mb-3 shadow-sm border-0">
      <div className="card-body">
        <div className="d-flex justify-content-between align-items-start mb-2">
          <Link
            to={`/profile/${post.user?.username}`}
            className="d-flex align-items-center text-decoration-none"
          >
            <i className="bi bi-person-circle fs-3 me-2 text-secondary"></i>
            <div>
              <div className="fw-semibold text-dark">{post.user?.full_name}</div>
              <div className="text-muted small">@{post.user?.username}</div>
            </div>
          </Link>
          {isOwner && (
            <button
              className="btn btn-sm btn-outline-danger"
              onClick={handleDelete}
              disabled={deleting}
              title="Delete post"
            >
              {deleting ? <span className="spinner-border spinner-border-sm" /> : <i className="bi bi-trash"></i>}
            </button>
          )}
        </div>

        <p className="mb-2" style={{ whiteSpace: 'pre-wrap' }}>{post.caption}</p>

        {post.attachments?.length > 0 && (
          <div className="row g-2 mb-2">
            {post.attachments.map((att) => (
              <div className="col-6 col-md-4" key={att.id}>
                <img
                  src={`${STORAGE_BASE_URL}/${att.storage_path}`}
                  alt="post attachment"
                  className="img-fluid rounded"
                  style={{ aspectRatio: '1 / 1', objectFit: 'cover', width: '100%' }}
                />
              </div>
            ))}
          </div>
        )}

        <div className="text-muted small">{new Date(post.created_at).toLocaleString()}</div>
      </div>
    </div>
  );
}
