import React from 'react';

export default function EmptyState({ icon = 'bi-inbox', message }) {
  return (
    <div className="text-center text-muted py-5">
      <i className={`bi ${icon} fs-1 d-block mb-2`}></i>
      <p className="mb-0">{message}</p>
    </div>
  );
}
