import React from 'react';

export default function Loader({ small = false }) {
  return (
    <div className={`d-flex justify-content-center ${small ? 'py-2' : 'py-5'}`}>
      <div className="spinner-border text-primary" role="status">
        <span className="visually-hidden">Loading...</span>
      </div>
    </div>
  );
}
