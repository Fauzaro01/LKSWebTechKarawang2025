import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { toast } from 'react-toastify';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { isAuthenticated, user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    const result = await Swal.fire({
      title: 'Logout from Facegram?',
      text: 'You will need to log in again to access your account.',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Logout',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#dc3545',
    });

    if (result.isConfirmed) {
      await logout();
      toast.success('You have been logged out');
      navigate('/login');
    }
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
      <div className="container">
        <Link className="navbar-brand fw-bold fs-4" to={isAuthenticated ? '/' : '/login'}>
          Facegram
        </Link>

        {isAuthenticated && (
          <div className="d-flex align-items-center gap-2 ms-auto">
            <Link to="/posts/create" className="btn btn-sm btn-primary">
              <i className="bi bi-plus-lg me-1"></i>
              <span className="d-none d-sm-inline">New Post</span>
            </Link>
            <Link
              to={`/profile/${user?.username}`}
              className="text-light text-decoration-none fw-semibold px-2"
            >
              <i className="bi bi-person-circle me-1"></i>
              {user?.username}
            </Link>
            <button className="btn btn-sm btn-outline-light" onClick={handleLogout}>
              <i className="bi bi-box-arrow-right"></i>
              <span className="d-none d-sm-inline ms-1">Logout</span>
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
