import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { useAuth } from '../context/AuthContext';
import { createPost } from '../services/postService';

export default function CreatePostPage() {
  useDocumentTitle('Create Post');
  const { user } = useAuth();
  const navigate = useNavigate();
  const [serverErrors, setServerErrors] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [previewUrls, setPreviewUrls] = useState([]);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();

  const files = watch('attachments');

  useEffect(() => {
    if (files && files.length > 0) {
      const urls = Array.from(files).map((f) => URL.createObjectURL(f));
      setPreviewUrls(urls);
      return () => urls.forEach((u) => URL.revokeObjectURL(u));
    }
    setPreviewUrls([]);
  }, [files]);

  const fieldError = (name) =>
    errors[name]?.message || (serverErrors?.[name] || serverErrors?.[`${name}.0`])?.join(', ');

  const onSubmit = async (data) => {
    setSubmitting(true);
    setServerErrors(null);
    try {
      const formData = new FormData();
      formData.append('caption', data.caption);
      Array.from(data.attachments || []).forEach((file) => formData.append('attachments[]', file));

      await createPost(formData);
      toast.success('Post created');
      navigate(`/profile/${user.username}`);
    } catch (err) {
      const res = err.response;
      if (res?.status === 422) {
        setServerErrors(res.data.errors);
      } else {
        toast.error('Failed to create post');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container py-4" style={{ maxWidth: 560 }}>
      <div className="card shadow-sm border-0">
        <div className="card-body p-4">
          <h4 className="fw-bold mb-4">Create New Post</h4>

          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <div className="mb-3">
              <label className="form-label">Caption</label>
              <textarea
                rows={3}
                className={`form-control ${fieldError('caption') ? 'is-invalid' : ''}`}
                {...register('caption', { required: 'The caption field is required.' })}
              />
              {fieldError('caption') && <div className="invalid-feedback">{fieldError('caption')}</div>}
            </div>

            <div className="mb-3">
              <label className="form-label">Photos</label>
              <input
                type="file"
                multiple
                accept="image/png,image/jpeg,image/jpg,image/webp,image/gif"
                className={`form-control ${fieldError('attachments') ? 'is-invalid' : ''}`}
                {...register('attachments', { required: 'Please attach at least one photo.' })}
              />
              {fieldError('attachments') && <div className="invalid-feedback">{fieldError('attachments')}</div>}
            </div>

            {previewUrls.length > 0 && (
              <div className="row g-2 mb-3">
                {previewUrls.map((url, i) => (
                  <div className="col-4" key={i}>
                    <img
                      src={url}
                      alt={`preview ${i + 1}`}
                      className="img-fluid rounded"
                      style={{ aspectRatio: '1 / 1', objectFit: 'cover', width: '100%' }}
                    />
                  </div>
                ))}
              </div>
            )}

            <button type="submit" className="btn btn-primary w-100" disabled={submitting}>
              {submitting && <span className="spinner-border spinner-border-sm me-2" />}
              Publish
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
