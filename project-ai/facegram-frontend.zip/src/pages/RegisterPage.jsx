import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { useAuth } from '../context/AuthContext';

export default function RegisterPage() {
  useDocumentTitle('Register');
  const { register: registerUser } = useAuth();
  const navigate = useNavigate();
  const [serverErrors, setServerErrors] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const fieldError = (name) => errors[name]?.message || serverErrors?.[name]?.join(', ');

  const onSubmit = async (data) => {
    setSubmitting(true);
    setServerErrors(null);
    try {
      const payload = { ...data, is_private: !!data.is_private };
      const result = await registerUser(payload);
      toast.success(result.message || 'Register success');
      navigate(`/profile/${result.user.username}`);
    } catch (err) {
      const res = err.response;
      if (res?.status === 422) {
        setServerErrors(res.data.errors);
      } else {
        toast.error('Something went wrong. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container py-5" style={{ maxWidth: 480 }}>
      <div className="card shadow-sm border-0">
        <div className="card-body p-4">
          <h3 className="text-center fw-bold mb-4">Create your account</h3>

          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <div className="mb-3">
              <label className="form-label">Full name</label>
              <input
                className={`form-control ${fieldError('full_name') ? 'is-invalid' : ''}`}
                {...register('full_name', { required: 'The full name field is required.' })}
              />
              {fieldError('full_name') && <div className="invalid-feedback">{fieldError('full_name')}</div>}
            </div>

            <div className="mb-3">
              <label className="form-label">Username</label>
              <input
                className={`form-control ${fieldError('username') ? 'is-invalid' : ''}`}
                {...register('username', {
                  required: 'The username field is required.',
                  minLength: { value: 3, message: 'The username must be at least 3 characters.' },
                  pattern: {
                    value: /^[a-zA-Z0-9._]+$/,
                    message: 'Only letters, numbers, dot (.) and underscore (_) are allowed.',
                  },
                })}
              />
              {fieldError('username') && <div className="invalid-feedback">{fieldError('username')}</div>}
            </div>

            <div className="mb-3">
              <label className="form-label">
                Bio <span className="text-muted small">(max 100 characters)</span>
              </label>
              <textarea
                rows={2}
                maxLength={100}
                className={`form-control ${fieldError('bio') ? 'is-invalid' : ''}`}
                {...register('bio', {
                  required: 'The bio field is required.',
                  maxLength: { value: 100, message: 'The bio field must not exceed 100 characters.' },
                })}
              />
              {fieldError('bio') && <div className="invalid-feedback">{fieldError('bio')}</div>}
            </div>

            <div className="mb-3">
              <label className="form-label">Password</label>
              <input
                type="password"
                className={`form-control ${fieldError('password') ? 'is-invalid' : ''}`}
                {...register('password', {
                  required: 'The password field is required.',
                  minLength: { value: 6, message: 'The password field must be at least 6 characters.' },
                })}
              />
              {fieldError('password') && <div className="invalid-feedback">{fieldError('password')}</div>}
            </div>

            <div className="form-check mb-4">
              <input
                type="checkbox"
                className="form-check-input"
                id="is_private"
                {...register('is_private')}
              />
              <label className="form-check-label" htmlFor="is_private">
                Make my account private
              </label>
            </div>

            <button type="submit" className="btn btn-primary w-100" disabled={submitting}>
              {submitting && <span className="spinner-border spinner-border-sm me-2" />}
              Register
            </button>
          </form>

          <p className="text-center mt-3 mb-0">
            Already have an account? <Link to="/login">Login</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
