import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import Swal from 'sweetalert2';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { useAuth } from '../context/AuthContext';
import { getUserDetail } from '../services/userService';
import { followUser, unfollowUser, getFollowers, getFollowing } from '../services/followService';
import PostCard from '../components/PostCard';
import UserListItem from '../components/UserListItem';
import Loader from '../components/Loader';
import EmptyState from '../components/EmptyState';

export default function ProfilePage() {
  const { username } = useParams();
  const navigate = useNavigate();

  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [followLoading, setFollowLoading] = useState(false);

  const [modal, setModal] = useState(null); // 'followers' | 'following' | null
  const [modalUsers, setModalUsers] = useState([]);
  const [modalLoading, setModalLoading] = useState(false);

  useDocumentTitle(profile ? `@${profile.username}` : 'Profile');

  const loadProfile = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getUserDetail(username);
      setProfile(res.data);
    } catch (err) {
      if (err.response?.status === 404) {
        toast.error('User not found');
        navigate('/');
      } else {
        toast.error('Failed to load profile');
      }
    } finally {
      setLoading(false);
    }
  }, [username, navigate]);

  useEffect(() => {
    loadProfile();
  }, [loadProfile]);

  const handleFollow = async () => {
    setFollowLoading(true);
    try {
      const res = await followUser(username);
      toast.success(res.data.message);
      setProfile((prev) => ({ ...prev, following_status: res.data.status }));
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to follow user');
    } finally {
      setFollowLoading(false);
    }
  };

  const handleUnfollow = async () => {
    const result = await Swal.fire({
      title: `Unfollow @${username}?`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Unfollow',
      confirmButtonColor: '#dc3545',
    });
    if (!result.isConfirmed) return;

    setFollowLoading(true);
    try {
      await unfollowUser(username);
      toast.success('Unfollowed successfully');
      setProfile((prev) => ({ ...prev, following_status: 'not-following' }));
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to unfollow user');
    } finally {
      setFollowLoading(false);
    }
  };

  const openModal = async (type) => {
    setModal(type);
    setModalLoading(true);
    try {
      if (type === 'followers') {
        const res = await getFollowers(username);
        setModalUsers(res.data.followers);
      } else {
        const res = await getFollowing();
        setModalUsers(res.data.following);
      }
    } catch {
      toast.error('Failed to load list');
    } finally {
      setModalLoading(false);
    }
  };

  const closeModal = () => {
    setModal(null);
    setModalUsers([]);
  };

  const handlePostDeleted = (id) => {
    setProfile((prev) => ({
      ...prev,
      posts: prev.posts.filter((p) => p.id !== id),
      posts_count: prev.posts_count - 1,
    }));
  };

  if (loading) return <Loader />;
  if (!profile) return null;

  const isOwnProfile = profile.is_your_account;
  const canSeePosts = !profile.is_private || profile.following_status === 'following' || isOwnProfile;

  return (
    <div className="container py-4" style={{ maxWidth: 720 }}>
      <div className="card shadow-sm border-0 mb-4">
        <div className="card-body">
          <div className="d-flex flex-wrap align-items-center justify-content-between gap-3">
            <div className="d-flex align-items-center">
              <i className="bi bi-person-circle" style={{ fontSize: '4rem' }}></i>
              <div className="ms-3">
                <h4 className="fw-bold mb-0">{profile.full_name}</h4>
                <div className="text-muted">@{profile.username}</div>
                {profile.is_private ? (
                  <span className="badge bg-secondary mt-1">
                    <i className="bi bi-lock-fill me-1"></i>Private
                  </span>
                ) : null}
              </div>
            </div>

            {!isOwnProfile &&
              (profile.following_status === 'following' ? (
                <button className="btn btn-outline-danger" onClick={handleUnfollow} disabled={followLoading}>
                  {followLoading && <span className="spinner-border spinner-border-sm me-2" />}
                  Unfollow
                </button>
              ) : profile.following_status === 'requested' ? (
                <button className="btn btn-secondary" disabled>
                  Requested
                </button>
              ) : (
                <button className="btn btn-primary" onClick={handleFollow} disabled={followLoading}>
                  {followLoading && <span className="spinner-border spinner-border-sm me-2" />}
                  Follow
                </button>
              ))}
          </div>

          <p className="mt-3 mb-3">{profile.bio}</p>

          <div className="d-flex gap-4">
            <div>
              <strong>{profile.posts_count}</strong> <span className="text-muted">Posts</span>
            </div>
            <button
              className="btn btn-link p-0 text-decoration-none text-dark"
              onClick={() => openModal('followers')}
            >
              <strong>{profile.followers_count}</strong> <span className="text-muted">Followers</span>
            </button>
            <button
              className="btn btn-link p-0 text-decoration-none text-dark"
              onClick={() => openModal('following')}
            >
              <strong>{profile.following_count}</strong> <span className="text-muted">Following</span>
            </button>
          </div>
        </div>
      </div>

      <h5 className="fw-bold mb-3">Posts</h5>
      {!canSeePosts ? (
        <EmptyState icon="bi-lock-fill" message="The account is private" />
      ) : profile.posts?.length === 0 ? (
        <EmptyState icon="bi-card-image" message="No posts yet." />
      ) : (
        profile.posts?.map((post) => (
          <PostCard key={post.id} post={{ ...post, user: profile }} onDeleted={handlePostDeleted} />
        ))
      )}

      {modal && (
        <div
          className="modal d-block"
          tabIndex="-1"
          style={{ background: 'rgba(0,0,0,0.5)' }}
          onClick={closeModal}
        >
          <div className="modal-dialog modal-dialog-centered" onClick={(e) => e.stopPropagation()}>
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title text-capitalize">{modal}</h5>
                <button className="btn-close" onClick={closeModal}></button>
              </div>
              <div className="modal-body" style={{ maxHeight: 400, overflowY: 'auto' }}>
                {modalLoading ? (
                  <Loader small />
                ) : modalUsers.length === 0 ? (
                  <EmptyState message={`No ${modal} yet.`} />
                ) : (
                  modalUsers.map((u) => <UserListItem key={u.id} user={u} />)
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
