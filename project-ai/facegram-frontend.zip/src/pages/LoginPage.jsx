import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  useDocumentTitle('Login');
  const { login } = useAuth();
  const navigate = useNavigate();
  const [serverErrors, setServerErrors] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const fieldError = (name) => errors[name]?.message || serverErrors?.[name]?.join(', ');

  const onSubmit = async (data) => {
    setSubmitting(true);
    setServerErrors(null);
    try {
      const result = await login(data);
      toast.success(result.message || 'Login success');
      navigate(`/profile/${result.user.username}`);
    } catch (err) {
      const res = err.response;
      if (res?.status === 401) {
        setServerErrors({ general: [res.data.message] });
      } else if (res?.status === 422) {
        setServerErrors(res.data.errors);
      } else {
        toast.error('Something went wrong. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container py-5" style={{ maxWidth: 420 }}>
      <div className="card shadow-sm border-0">
        <div className="card-body p-4">
          <h3 className="text-center fw-bold mb-4">Sign in to Facegram</h3>

          {serverErrors?.general && (
            <div className="alert alert-danger">{serverErrors.general.join(', ')}</div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <div className="mb-3">
              <label className="form-label">Username</label>
              <input
                type="text"
                className={`form-control ${fieldError('username') ? 'is-invalid' : ''}`}
                {...register('username', { required: 'Username is required' })}
              />
              {fieldError('username') && <div className="invalid-feedback">{fieldError('username')}</div>}
            </div>

            <div className="mb-3">
              <label className="form-label">Password</label>
              <input
                type="password"
                className={`form-control ${fieldError('password') ? 'is-invalid' : ''}`}
                {...register('password', { required: 'Password is required' })}
              />
              {fieldError('password') && <div className="invalid-feedback">{fieldError('password')}</div>}
            </div>

            <button type="submit" className="btn btn-primary w-100" disabled={submitting}>
              {submitting && <span className="spinner-border spinner-border-sm me-2" />}
              Login
            </button>
          </form>

          <p className="text-center mt-3 mb-0">
            Don&apos;t have an account? <Link to="/register">Register</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
