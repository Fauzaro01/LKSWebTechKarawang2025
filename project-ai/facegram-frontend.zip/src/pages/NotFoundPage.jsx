import React from 'react';
import { Link } from 'react-router-dom';
import useDocumentTitle from '../hooks/useDocumentTitle';

export default function NotFoundPage() {
  useDocumentTitle('Page Not Found');
  return (
    <div className="container text-center py-5">
      <h1 className="display-1 fw-bold">404</h1>
      <p className="text-muted mb-4">The page you are looking for doesn&apos;t exist.</p>
      <Link to="/" className="btn btn-primary">
        Go Home
      </Link>
    </div>
  );
}
