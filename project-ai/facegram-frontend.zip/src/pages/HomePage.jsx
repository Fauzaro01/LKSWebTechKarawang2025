import React, { useState, useEffect, useCallback, useRef } from 'react';
import { toast } from 'react-toastify';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { useAuth } from '../context/AuthContext';
import { getPosts } from '../services/postService';
import { getUsers } from '../services/userService';
import { getFollowers, followUser, acceptFollowRequest } from '../services/followService';
import PostCard from '../components/PostCard';
import UserListItem from '../components/UserListItem';
import Loader from '../components/Loader';
import EmptyState from '../components/EmptyState';

// Per spec: first load shows 10 newest posts, every subsequent scroll-to-bottom
// load fetches 7 more. The API only exposes simple page/size pagination, so we
// keep a running "page" cursor per request and de-duplicate by post id on the
// client side to safely handle the change in page size between the first and
// later requests.
const INITIAL_SIZE = 10;
const NEXT_SIZE = 7;

export default function HomePage() {
  useDocumentTitle('Home');
  const { user } = useAuth();

  const [posts, setPosts] = useState([]);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const pageRef = useRef(0);
  const seenIds = useRef(new Set());

  const [exploreUsers, setExploreUsers] = useState([]);
  const [loadingExplore, setLoadingExplore] = useState(true);

  const [followRequests, setFollowRequests] = useState([]);
  const [loadingRequests, setLoadingRequests] = useState(true);

  const appendPosts = (newPosts) => {
    const unique = newPosts.filter((p) => !seenIds.current.has(p.id));
    unique.forEach((p) => seenIds.current.add(p.id));
    setPosts((prev) => [...prev, ...unique]);
  };

  const loadInitialPosts = useCallback(async () => {
    setLoadingPosts(true);
    try {
      const res = await getPosts(0, INITIAL_SIZE);
      appendPosts(res.data.posts);
      setHasMore(res.data.posts.length === INITIAL_SIZE);
      pageRef.current = 1;
    } catch {
      toast.error('Failed to load feed');
    } finally {
      setLoadingPosts(false);
    }
  }, []);

  const loadMorePosts = useCallback(async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    try {
      const res = await getPosts(pageRef.current, NEXT_SIZE);
      appendPosts(res.data.posts);
      setHasMore(res.data.posts.length === NEXT_SIZE);
      pageRef.current += 1;
    } catch {
      toast.error('Failed to load more posts');
    } finally {
      setLoadingMore(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadingMore, hasMore]);

  useEffect(() => {
    loadInitialPosts();
  }, [loadInitialPosts]);

  useEffect(() => {
    const onScroll = () => {
      const reachedBottom = window.innerHeight + window.scrollY >= document.body.offsetHeight - 200;
      if (reachedBottom) loadMorePosts();
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, [loadMorePosts]);

  const loadExplore = useCallback(async () => {
    setLoadingExplore(true);
    try {
      const res = await getUsers();
      setExploreUsers(res.data.users);
    } catch {
      toast.error('Failed to load suggested users');
    } finally {
      setLoadingExplore(false);
    }
  }, []);

  const loadFollowRequests = useCallback(async () => {
    if (!user?.username) return;
    setLoadingRequests(true);
    try {
      const res = await getFollowers(user.username);
      setFollowRequests(res.data.followers.filter((f) => f.is_requested));
    } catch {
      toast.error('Failed to load follow requests');
    } finally {
      setLoadingRequests(false);
    }
  }, [user?.username]);

  useEffect(() => {
    loadExplore();
    if (user?.is_private) {
      loadFollowRequests();
    } else {
      setLoadingRequests(false);
    }
  }, [loadExplore, loadFollowRequests, user?.is_private]);

  const handleFollow = async (username) => {
    try {
      const res = await followUser(username);
      toast.success(res.data.message);
      setExploreUsers((prev) => prev.filter((u) => u.username !== username));
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to follow user');
    }
  };

  const handleAccept = async (username) => {
    try {
      const res = await acceptFollowRequest(username);
      toast.success(res.data.message);
      setFollowRequests((prev) => prev.filter((f) => f.username !== username));
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to accept request');
    }
  };

  const handlePostDeleted = (id) => {
    setPosts((prev) => prev.filter((p) => p.id !== id));
  };

  // Hide the section entirely when the account is not private, or there are
  // no pending requests, per the document's requirement.
  const showFollowRequests = user?.is_private && (loadingRequests || followRequests.length > 0);

  return (
    <div className="container py-4">
      <div className="row">
        <div className="col-lg-7">
          <h5 className="fw-bold mb-3">News Feed</h5>
          {loadingPosts ? (
            <Loader />
          ) : posts.length === 0 ? (
            <EmptyState icon="bi-card-image" message="No posts yet. Follow people to see their posts here." />
          ) : (
            <>
              {posts.map((post) => (
                <PostCard key={post.id} post={post} onDeleted={handlePostDeleted} />
              ))}
              {loadingMore && <Loader small />}
              {!hasMore && posts.length > 0 && (
                <p className="text-center text-muted small">You&apos;re all caught up</p>
              )}
            </>
          )}
        </div>

        <div className="col-lg-5">
          {showFollowRequests && (
            <div className="card mb-4 shadow-sm border-0">
              <div className="card-header bg-white fw-semibold">Follow Requests</div>
              <div className="card-body">
                {loadingRequests ? (
                  <Loader small />
                ) : (
                  followRequests.map((req) => (
                    <UserListItem
                      key={req.id}
                      user={req}
                      action={
                        <button className="btn btn-sm btn-primary" onClick={() => handleAccept(req.username)}>
                          Accept
                        </button>
                      }
                    />
                  ))
                )}
              </div>
            </div>
          )}

          <div className="card shadow-sm border-0">
            <div className="card-header bg-white fw-semibold">Explore People</div>
            <div className="card-body">
              {loadingExplore ? (
                <Loader small />
              ) : exploreUsers.length === 0 ? (
                <EmptyState icon="bi-people" message="No new people to explore right now." />
              ) : (
                exploreUsers.map((u) => (
                  <UserListItem
                    key={u.id}
                    user={u}
                    action={
                      <button className="btn btn-sm btn-outline-primary" onClick={() => handleFollow(u.username)}>
                        Follow
                      </button>
                    }
                  />
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
