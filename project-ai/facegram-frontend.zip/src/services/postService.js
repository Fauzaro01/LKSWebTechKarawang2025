import api from './api';

export const getPosts = (page = 0, size = 10) =>
  api.get('/posts', { params: { page, size } });

export const createPost = (formData) =>
  api.post('/posts', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });

export const deletePost = (id) => api.delete(`/posts/${id}`);
