import api from './api';

export const followUser = (username) => api.post(`/users/${username}/follow`);

export const unfollowUser = (username) => api.delete(`/users/${username}/unfollow`);

export const getFollowing = () => api.get('/following');

export const getFollowers = (username) => api.get(`/users/${username}/followers`);

export const acceptFollowRequest = (username) => api.put(`/users/${username}/accept`);
