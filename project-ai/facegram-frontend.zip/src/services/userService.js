import api from './api';

// Get all users that are not followed by the logged in user (Explore People).
export const getUsers = () => api.get('/users');

// Get detailed data of a single user by username (Profile page).
export const getUserDetail = (username) => api.get(`/users/${username}`);
