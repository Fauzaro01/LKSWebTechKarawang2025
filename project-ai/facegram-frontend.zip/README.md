# Facegram — Frontend (React)

Frontend untuk aplikasi media sosial **Facegram**, dibangun memenuhi seluruh requirement pada
`Naskah Soal LKS WebTech Tingkat Kabupaten Karawang 2025` (Fase 2 — Frontend Development).

## Tech Stack

- React 19 (Functional Component + Hooks)
- React Router DOM v6 (routing & protected route)
- Axios (HTTP client + interceptor Bearer token)
- Bootstrap 5 + Bootstrap Icons (UI, responsive)
- React Hook Form (validasi form sisi klien)
- SweetAlert2 (konfirmasi aksi: logout, unfollow, delete post)
- React Toastify (notifikasi sukses/gagal)
- Vite (build tool)

## Cara Menjalankan

```bash
cd facegram-frontend
npm install
cp .env.example .env   # sesuaikan VITE_API_BASE_URL & VITE_STORAGE_BASE_URL dengan backend Laravel Anda
npm run dev
```

Aplikasi berjalan di `http://localhost:5173`. Pastikan backend Laravel (Fase 1) sudah berjalan dan
CORS mengizinkan origin tersebut.

## Struktur Folder

```
src/
├── api/                 (reserved — saat ini axios instance ada di services/api.js)
├── assets/styles/        global CSS
├── components/           reusable UI components
│   ├── Navbar.jsx
│   ├── ProtectedRoute.jsx   redirect ke /login jika belum auth
│   ├── GuestRoute.jsx       redirect ke /profile jika sudah auth (untuk login/register)
│   ├── PostCard.jsx         kartu postingan + delete
│   ├── UserListItem.jsx     baris user (explore/followers/following/requests)
│   ├── Loader.jsx
│   └── EmptyState.jsx
├── context/
│   └── AuthContext.jsx   state management auth (user, token, login, register, logout)
├── hooks/
│   └── useDocumentTitle.js  set document.title dinamis per halaman
├── pages/
│   ├── LoginPage.jsx
│   ├── RegisterPage.jsx
│   ├── HomePage.jsx       news feed (infinite scroll) + explore + follow requests
│   ├── ProfilePage.jsx    info user, follow/unfollow, modal followers/following, posts
│   ├── CreatePostPage.jsx
│   └── NotFoundPage.jsx
├── services/             seluruh logic pemanggilan REST API
│   ├── api.js             axios instance + interceptor (Bearer token, auto-logout on 401)
│   ├── authService.js     register, login, logout
│   ├── postService.js     getPosts, createPost, deletePost
│   ├── userService.js     getUsers, getUserDetail
│   └── followService.js   follow, unfollow, getFollowing, getFollowers, acceptFollowRequest
├── utils/
│   └── storage.js        persist token & user ke localStorage
├── App.jsx               konfigurasi routing
└── main.jsx              entry point (providers, BrowserRouter, ToastContainer)
```

## State Management

Menggunakan **React Context API** (`AuthContext`) untuk state autentikasi global (user, token,
status login). Dipilih dibanding Redux/Zustand karena scope aplikasi (1 entitas global: sesi user)
tidak membutuhkan state management library tambahan — cukup dengan Context + hooks bawaan React,
sesuai prinsip "jangan over-engineer". State per-halaman (feed, daftar user, dsb.) dikelola lokal
dengan `useState`/`useEffect` di tiap page karena tidak perlu dibagikan ke komponen lain.

## Flow Routing

```
/login        (Guest only)   → redirect ke /profile/:username jika sudah login
/register     (Guest only)   → redirect ke /profile/:username jika sudah login
/             (Protected)    → Homepage (feed, explore, follow requests)
/profile/:username (Protected) → Profile (milik sendiri atau orang lain)
/posts/create (Protected)    → Form buat postingan baru
*             → 404
```

`ProtectedRoute` dan `GuestRoute` menggunakan `<Outlet />` React Router v6 sehingga semua halaman di
dalamnya otomatis terlindungi tanpa duplikasi logic.

## Axios & Interceptor

`services/api.js` membuat instance axios dengan `baseURL` dari `VITE_API_BASE_URL`. Request
interceptor otomatis menambahkan header `Authorization: Bearer <token>` dari localStorage ke setiap
request. Response interceptor menangkap status `401 Unauthenticated` secara global: token dihapus
dan user diarahkan ke `/login` — ini mencegah duplikasi error-handling 401 di setiap halaman.

## Penanganan Error & Loading

- Setiap request menampilkan loading state (`Loader` spinner / spinner pada tombol submit).
- Error validasi (422) ditampilkan per-field langsung di bawah input (selaras dengan response
  `errors` API).
- Error lain (404, 403, 401 di luar interceptor) ditampilkan via toast.
- Aksi destructive (logout, unfollow, delete post) dikonfirmasi dengan SweetAlert2 sebelum dieksekusi.

## Keputusan untuk Requirement yang Ambigu

1. **Infinite scroll dengan ukuran halaman berbeda (10 awal, 7 berikutnya).**
   API hanya menyediakan parameter `page` & `size` (offset = `page * size` secara umum). Karena
   ukuran halaman berubah dari 10 menjadi 7, request kedua dan seterusnya tidak bisa dijamin selaras
   sempurna dengan offset murni. Solusi yang dipilih: tetap mengikuti instruksi dokumen secara
   literal (request pertama `size=10`, request berikutnya `size=7` dengan `page` yang terus
   bertambah), lalu melakukan **deduplikasi di sisi klien berdasarkan `post.id`** agar tidak ada
   postingan dobel jika terjadi overlap. Ini adalah praktik umum infinite-scroll modern (mis. media
   sosial) yang tetap defensif terhadap pagination yang tidak strict cursor-based.

2. **Follow Requests di Homepage.**
   Dokumen tidak menyediakan endpoint khusus "incoming follow requests", tetapi endpoint
   `GET /users/:username/followers` mengembalikan field `is_requested` pada setiap follower. Maka
   diasumsikan: daftar follow request yang harus ditampilkan adalah followers dari user yang sedang
   login dengan `is_requested === true` (permintaan yang belum di-accept). Tombol "Accept" memanggil
   `PUT /users/:username/accept` dengan `:username` milik si pengirim permintaan (follower),
   sesuai contoh response endpoint accept.

3. **Atribut `user` pada Post di halaman Profile.**
   Endpoint `GET /users/:username` mengembalikan array `posts` tanpa field `user` (karena sudah
   jelas semua post milik user yang sedang dilihat). Untuk reuse komponen `PostCard` yang sama
   dengan Homepage, frontend menyisipkan data user dari hasil `getUserDetail` ke setiap post sebelum
   dirender, tanpa mengubah kontrak API.

4. **Path penyimpanan attachment (`storage_path`).**
   API hanya mengembalikan path relatif (mis. `posts/xxx.jpg`). Frontend menggabungkannya dengan
   `VITE_STORAGE_BASE_URL` (default mengikuti symlink `storage` Laravel) untuk membentuk URL gambar
   penuh. Sesuaikan environment variable ini dengan konfigurasi storage backend Anda.

5. **Redirect setelah Register/Login.**
   Dokumen tidak menyebutkan tujuan redirect setelah register berhasil. Karena response register
   juga mengembalikan `token` (user otomatis ter-autentikasi), frontend langsung mengarahkan ke
   halaman profil sendiri — sama seperti setelah login — agar pengalaman pengguna konsisten dan
   tidak perlu login ulang.

## Catatan Lingkungan Build

Sandbox pembuatan kode ini tidak memiliki akses internet, sehingga `npm install` **belum dijalankan**
di sini dan dependency belum diverifikasi dengan build/lint otomatis. Semua kode ditulis manual
sesuai API yang stabil dari masing-masing library (React Router v6, React Hook Form v7, dst).
Mohon jalankan `npm install` & `npm run dev` di mesin Anda yang memiliki akses internet untuk
memverifikasi build sebelum digunakan saat lomba/demo.
